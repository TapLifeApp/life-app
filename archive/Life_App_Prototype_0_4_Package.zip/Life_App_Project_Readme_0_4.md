# Life App — project handoff (Prototype 0.4)

## Product principle
Life App teaches the journey: show users where they are, explain evidence-informed progress, break goals into manageable milestones, and adapt the next step without shame.

## Current deliverables
- `Life_App_Prototype_0_4.html` — standalone mobile-friendly browser prototype.
- `Life_App_Prototype_0_3.html` — previous version for comparison.
- `Life_App_MVP_Blueprint_Draft_0_1.docx` — first MVP blueprint draft.
- `Life_App_Teaching_and_Progress_System_Spec_0_1.docx` — cross-module teaching requirements.
- `Life_App_Fitness_Progression_Rules_0_1.docx` — draft fitness progression logic.
- `Life_App_Fitness_Competitor_Scorecard_Template.xlsx` — competitor research workspace.
- `Life_App_User_Validation_Guide_0_1.docx` — interview and prototype test guide.

## Open and use
Open `Life_App_Prototype_0_4.html` in a modern browser. It does not require installation or a server. Settings and workout history are stored in that browser's local storage. Clearing browser data can remove them. There are no accounts or cloud backups.

## Prototype 0.4 changes
- Workout exercise list changes based on selected equipment (dumbbells, bodyweight, bands, or gym equipment).
- Workout list length responds to selected session duration; beginner selection limits the initial plan to four movements.
- Weekly dashboard counts only sessions since Monday, while the progress page still shows all-time history.
- Data is migrated from the previous prototype storage key when available.
- Your Path explains the signals used by the current rule-based recommendation.

## Verification
- JavaScript syntax check: passed with Node.js `node --check`.
- Static content checks: see test report.
- Full browser rendering, mobile device testing, timer behavior under backgrounding, accessibility audit, and user usability testing remain outstanding.

## Known limitations / risks
- This is a prototype, not a production app; it has no accounts, cloud sync, backend, server-side security, analytics, or app-store packaging.
- The exercise library and recommendation rules are illustrative and not clinically validated. They do not screen for injury, illness, pregnancy, disability, or contraindications. Users should stop if an exercise causes pain and seek qualified advice where appropriate.
- Duration is currently used to select the number of exercise cards, not to guarantee the exact session runtime.
- Progression is rule-based and can overstate readiness if check-ins are not tied to individual completed sessions. The production design should bind each check-in to a session and include a more careful recovery/safety flow.
- Do not use this prototype to store sensitive real-world health information.

## Roadmap — next unfinished tasks
1. Run a full interactive browser and mobile usability test; fix navigation, persistence, and timer edge cases.
2. Tie each effort check-in to a specific workout; revise progression gates and add a “pain / unsafe” stop-and-adjust response.
3. Finish competitor research using official product information and observed hands-on tests; keep evidence separate from assumptions.
4. Conduct 8–12 user interviews and 5 observed prototype tests; do not claim validation before they occur.
5. Revise and approve the MVP specification based on evidence.
6. Compare production technology options and choose an architecture; establish a founder-controlled source repository.
7. Build authentication, secure backend, sync/export/delete controls, tests, and app packaging before any public release.

## Status discipline
Created does not mean validated. Syntax checked does not mean browser tested. A prototype does not mean a production app. Keep these distinctions explicit in every project update.
